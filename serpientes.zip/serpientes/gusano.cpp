#include <bits/stdc++.h>
#include "gusano.h"
using namespace std;

mt19937_64 seed(chrono::steady_clock::now().time_since_epoch().count());

Gusano::Gusano(){}

Gusano::Gusano(int tamano, int modX, int modY,int red,int blue, int green):tamano(tamano),modX(modX),modY(modY),r(red),b(blue),g(green){
	//Crear una tray rand
	srand(time(NULL));

	int mov[2] = {1,-1};
	multi = uniform_int_distribution<int>(1, 10)(seed);

	Punto vec(mov[uniform_int_distribution<int>(0, 1)(seed)],
	mov[uniform_int_distribution<int>(0, 1)(seed)]);

	Punto start(uniform_int_distribution<int>(0, modX)(seed),
	uniform_int_distribution<int>(0, modY)(seed));
	
	puntos.resize(multi*tamano);
	puntos[0] = start;
	
	for(int i=1; i < multi*tamano; i++){
		int x = int(puntos[i-1].getX()+vec.getX())%modX;
		int y = int(puntos[i-1].getY()+vec.getY())%modY;
		if(x < 0) x+=modX;
		if(y < 0) y+=modY;
		puntos[i] = Punto(double(x),double(y));
		//cout << "Ponemos a " << puntos[i].getX() << " y= "<< puntos[i].getY() << endl;
	}
	offset = 0;
}

vector<Punto> Gusano::avanzar(){
	if(offset + tamano == puntos.size()){
		vector<Punto> aux;
		for(int i = offset; i < puntos.size(); i++){
			aux.push_back(puntos[i]);
		}

		puntos.clear(); //limpiamos
		for(int i =0; i < aux.size(); i++) 
			puntos.push_back(aux[i]);
		
		int opc = uniform_int_distribution<int>(0, 2)(seed);
		//int opc = 1;
		if(opc == 0){
			//circulo
			int radius = uniform_int_distribution<int>(10,250)(seed);
			int r2 = radius*radius;
			
			int multi[2] = {1,-1};
			int pos = multi[uniform_int_distribution<int>(0,1)(seed)];

			int xcenter = puntos[puntos.size()-1].getX() + (pos * radius);
			int ycenter = int(puntos[puntos.size()-1].getY());
			
			xcenter%=modX;
			if(xcenter < 0) xcenter+=modX;
			ycenter%=modY;
			if(ycenter< 0) ycenter+=modY;

			int arr_ab = uniform_int_distribution<int>(0,1)(seed);
			
			vector<Punto> aux2;
			int x,y;
			
			for(x = -radius; x <= radius; x++){
				y = (int)(sqrt(r2- x*x)+0.5);
				if(arr_ab){// 1-> arriba
					int x1  = (xcenter+x)%modX;
					if(x1 < 0) x1+=modX;
					int y1 = (ycenter-y)%modY;
					if(y1<0) y1+=modY;
					aux2.push_back(Punto(x1,y1));
				}
				else{
					int x1  = (xcenter+x)%modX;
					if(x1 < 0) x1+=modX;
					int y1 = (ycenter+y)%modY;
					if(y1<0) y1+=modY;
					aux2.push_back(Punto(x1,y1));
				}
			}

			if(pos == -1){
				vector<Punto> rev_aux;
				for(int i = aux2.size()-1; i >=0; i--){
					rev_aux.push_back(aux2[i]);
				}
				aux2.clear();
				for(int i =0; i < rev_aux.size(); i++){
					aux2.push_back(rev_aux[i]);
				}
				rev_aux.clear();
			}
			
			for(Punto e: aux2){
				puntos.push_back(e);
			}

		}
		else if(opc == 1){
			///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			int curvas = uniform_int_distribution<int>(1,5)(seed);
			int arriba = uniform_int_distribution<int>(0,1)(seed);
			
			int radius = uniform_int_distribution<int>(10,150)(seed);
			int r2 = radius*radius;
			
			int multi[2] = {1,-1};
			int pos = multi[uniform_int_distribution<int>(0,1)(seed)];

			for(int cont = 0; cont < curvas; cont++){

				int xcenter = puntos[puntos.size()-1].getX() + (pos * radius);
				int ycenter = int(puntos[puntos.size()-1].getY());

				xcenter%=modX;
				if(xcenter < 0) xcenter+=modX;
				ycenter%=modY;
				if(ycenter< 0) ycenter+=modY;
				
				vector<Punto> aux2;
				int x,y;
				
				for(x = -radius; x <= radius; x++){
					y = (int)(sqrt(r2- x*x)+0.5);
					if(arriba){// 1-> arriba
						int x1  = (xcenter+x)%modX;
						if(x1 < 0) x1+=modX;
						int y1 = (ycenter-y)%modY;
						if(y1<0) y1+=modY;
						aux2.push_back(Punto(x1,y1));
					}
					else{
						int x1  = (xcenter+x)%modX;
						if(x1 < 0) x1+=modX;
						int y1 = (ycenter+y)%modY;
						if(y1<0) y1+=modY;
						aux2.push_back(Punto(x1,y1));
					}
				}

				if(pos == -1){
					vector<Punto> rev_aux;
					for(int i = aux2.size()-1; i >=0; i--){
						rev_aux.push_back(aux2[i]);
					}
					aux2.clear();
					for(int i =0; i < rev_aux.size(); i++){
						aux2.push_back(rev_aux[i]);
					}
					rev_aux.clear();
				}
				
				for(Punto e: aux2){
					puntos.push_back(e);
				}
				arriba = !arriba;
			}
			
		}
		else{
			//recta
			int mov[3] = {1,-1,0};
			int escalar = 1;
			Punto vec(double(escalar*mov[rand()%3]),double(escalar*mov[rand()%3]));
			int idx=puntos.size()-1;
			for(int i =0; i < tamano; i++){
				int x = int(puntos[idx].getX()+vec.getX())%modX;
				if(x < 0) x+=modX;
				int y = int(puntos[idx].getY() + vec.getY())%modY;
				if(y < 0) y+=modY;
				puntos.push_back(Punto(double(x),double(y)));
				idx++;
			}
		}
		offset = 0;
	}
	vector<Punto> ans;
	int cont =0;
	for(int i=offset; i < offset + tamano; i++ ){
		ans.push_back(puntos[i]);
	}
	offset++;
	return ans;
}

pair<int,pair<int,int>> Gusano::getColor(){
	return pair<int,pair<int,int>>(r,pair<int,int>(g,b));
}
