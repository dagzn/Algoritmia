#include "punto.h"

Punto::Punto(){}

Punto::Punto(double xx, double yy): x(xx),y(yy){}

double Punto::getX(){
	return x;
}

double Punto::getY(){
	return y;
}

