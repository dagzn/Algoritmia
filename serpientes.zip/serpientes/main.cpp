#include <bits/stdc++.h>
using namespace std;
#include "punto.h"
#include "gusano.h"
#include "gfx.h"
#include <unistd.h>
mt19937_64 seed2(chrono::steady_clock::now().time_since_epoch().count());

int main(){
	int x ,y,cantidad;
	cin >> cantidad;
	gfx_open(900,900,"Gusanos");
	vector<Gusano*> gs(cantidad);
	for(int i=0; i < cantidad; i++) gs[i] = new Gusano(uniform_int_distribution<int>(50, 100)(seed2),900,900,
		uniform_int_distribution<int>(0, 200)(seed2),
		uniform_int_distribution<int>(0, 200)(seed2),uniform_int_distribution<int>(0, 200)(seed2));
	
	while(true){
		for(Gusano* g: gs){
			vector<Punto> puntos = g->avanzar();
			for(auto p: puntos){
				auto colores = g->getColor();
				gfx_color(colores.first,colores.second.first,colores.second.second);
				int x1 = int(p.getX());
				int y1 = int(p.getY());
				if(x1 < 0) x1+=x;
				if(y1 < 0) y1+=y;
				gfx_point(x1,y1);
				//gfx_flush();
			}
			gfx_flush();
		}
		//gfx_flush();
		//gfx_wait();
		gfx_clear();
		usleep(1000);
	}
	return 0;
}

