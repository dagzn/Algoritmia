#include "punto.h"
#include <bits/stdc++.h>
using namespace std;
#ifndef GUSANO_H_
#define GUSANO_H_

class Gusano{
private:
	int r,g,b;
	std::vector<Punto> puntos;
	int tamano;
	int modX,modY;
	int offset;
	int multi;
public:
	Gusano();
	Gusano(int,int,int,int,int,int);
	std::vector<Punto> avanzar();
	pair<int,pair<int,int>> getColor();
};

#endif
