#ifndef PUNTO_H
#define PUNTO_H

class Punto{
private:
	double x;
	double y;
public:
	Punto();
	Punto(double,double);
	double getX();
	double getY();
};

#endif
